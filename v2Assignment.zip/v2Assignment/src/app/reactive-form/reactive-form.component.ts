import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  title = ' TEST DRIVINGthis 2019 COMPASS ALTITUDE FWD!'
  userForm!: FormGroup;
  RADIO_LIST = [
    { name: 'At the dealer ship', checked: false },
    { name: 'my Home (no extra charge)', checked: false },
    { name: 'Other location(no extra charge)',  checked: true }
    
  ];
  constructor(public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    
    this.userForm = this.formBuilder.group({
     

  
    date :['',[Validators.required]],
    time: ['',[Validators.required]],
    firstName: ['',[Validators.required, Validators.minLength(4)]],
    lastName:['', [Validators.required]],
    zipcode:['',[Validators.required]],
    phone:['',[Validators.required]],
    email:['',[Validators.required]],
    TestDriveLocation:['',[Validators.required]],
    homeAddress:['',[Validators.required]],
    city:['',[Validators.required]],
    state:['',[Validators.required]]

  
    })
  }
get getControl(){
  return this.userForm.controls;
}
get datepicker() {
  return this.userForm.get('datepicker');
}
 onSubmit() {
   console.log(this.userForm);
   
 }
}
